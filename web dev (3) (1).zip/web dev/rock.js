function loadXMLDoc (){
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        check(this)

       // Typical action to be performed when the document is ready:
       document.getElementById("form-outline").innerHTML = xhttp.responseText;
    }
};
}
xhttp.open("GET", "Code.xml", true);
xhttp.send();

function check(x)
        {
            var i = 0;
            var data = document.getElementById("mySearch").value;

            for (i = 0; i < x.length; i++)
            {
                if (data === x[i].getAttribute("disc"))
                {
                    document.getElementById("id").innerHTML = x[i].getElementsByTagName("code")[0].childNodes[0].nodeValue;
                    document.getElementById("category").innerHTML = x[i].getElementsByTagName("category")[0].childNodes[0].nodeValue;
                    document.getElementById("title").innerHTML = x[i].getElementsByTagName("title")[0].childNodes[0].nodeValue;
                    document.getElementById("desc").innerHTML = x[i].getElementsByTagName("description")[0].childNodes[0].nodeValue;
                    document.getElementById("quity").innerHTML = x[i].getElementsByTagName("quantity")[0].childNodes[0].nodeValue;
                    document.getElementById("price").innerHTML = x[i].getElementsByTagName("price")[0].childNodes[0].nodeValue;

                    document.getElementById("code").style.visibility = "visible";



                    break;

                }

            }


        }